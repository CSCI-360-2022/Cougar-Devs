import { FlatList, StyleSheet, Text, View, SafeAreaView, Pressable, ActivityIndicator } from 'react-native'
import { DataStore } from "aws-amplify";
import { Events } from '../../models';
import { useState, useEffect } from 'react';
import { useNavigation, useRoute } from '@react-navigation/native';
import cart from '../../../assets/data/Cart.json'
import { StatusBar } from 'expo-status-bar';
import {AntDesign} from '@expo/vector-icons'
import { useBasketContext } from '../../contexts/BasketContext';


const BasketScreen = () => {
  const [event, setEvent] = useState(null);
  const [ticket, setTickets] = useState(1);
  

  const navigation = useNavigation();
  const route = useRoute();
  const id = route.params.id;
  const maxTicket = route.params.maxTicket;
  const {addEventToBasket} = useBasketContext();
  useEffect(() => {
    DataStore.query(Events, id).then(setEvent);
  }, [])

  const onAddToBasket = async () => {
    await addEventToBasket(event, ticket)
    navigation.navigate("Payment", {id: event.id, ticket})
  }
  const increaseTicket = () => {
 
      setTickets(ticket + 1)
  
    
  }

  const decrementTicket = () => {
    if(ticket >= 2){
        setTickets(ticket - 1)
    }
  }

  const getTotal = () => {
    return event.price * ticket
  }

  const getMaxTicket = () => {


  }

  

  if (!event){
    return <ActivityIndicator/>
  }

  




  return (
    <SafeAreaView style={{flex: 1, width: '100%'}}>
        <StatusBar style='dark'/>
        <View style={{paddingHorizontal: 10, paddingLeft: 10}}>
            <Text style={styles.title}> {event.name} </Text>  
            <Text style={[styles.subtitle, {marginBottom: 5}]}> {event.organization}</Text>  
            <Text style={styles.subtitle}> {event.date} </Text>
        </View>    
        <View style={styles.separator}/>

        <View style={styles.subpage}>
            <Text style={{marginBottom: 15, fontFamily: 'Urbanist-SemiBold', fontSize: 20, color: '#800000'}}> How many tickets would you like?</Text>
            <View style={styles.row}>
            <Pressable onPress={() => decrementTicket()}>
            <AntDesign name="minuscircleo" size={40} color="#800000"/>
            </Pressable>
            <Text style={styles.quantity}>{ticket}</Text>
            <Pressable onPress={() => increaseTicket()}>
            <AntDesign name="pluscircleo" size={40} color="#800000"/>
            </Pressable>
            </View>
        </View>

        <View style={styles.footer}>
                       
                        <Pressable onPress={onAddToBasket}style={{backgroundColor:'#800000', width: '100%', alignItems: 'center', height: 60, borderRadius: 20, justifyContent: 'center'}}>
                            <Text style={styles.payButton}> Purchase {ticket} tickets &#8226; ${getTotal().toFixed(2)} </Text>
                        </Pressable>
                
        </View>
    </SafeAreaView>
  )
}

export default BasketScreen

const styles = StyleSheet.create({

    title: {
        fontSize: 30,
        fontFamily: "Urbanist-SemiBold",
        marginVertical: 10,
        color: '#800000',
    },

    subtitle: {
        fontSize: 20,
        marginBottom: 20,
        color: '#800000',
        fontFamily: 'Urbanist-SemiBold'
    },
    
    separator:{
        height: 1,
        backgroundColor: '#800000',
        width: '100%',
        marginBottom: 10,
    },

    subpage: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },

    row: {
        flexDirection: 'row',
        alignItems: 'center',        
    },

    quantity: {
        marginHorizontal: 20,
        fontSize: 25,
        fontFamily: 'Urbanist-SemiBold',
        color: '#800000'
    },

    footer: {
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 10,
        bottom: 30,
        width: '100%',
        backgroundColor: 'white',
        height: 40,
     },

     payButton: {
        fontFamily: "Urbanist-SemiBold",
        fontSize: 20,
        color: 'white'
     }
})