import { View, Text, ActivityIndicator, StyleSheet, SafeAreaView, Pressable, KeyboardAvoidingView , TouchableWithoutFeedback, Keyboard, ScrollView, Animated, Dimensions} from 'react-native'
import React from 'react'
import { DataStore } from "aws-amplify";
import { Events } from '../../models';
import { useState, useEffect } from 'react';
import { useNavigation, useRoute } from '@react-navigation/native';
import { TextInput } from 'react-native-paper';

const CreditCardScreen = () => {

    const [event, setEvent] = useState(null);
    const [creditCardNumber, setCreditCardNumber] = useState('')
    const [CVV,setCVV] = useState('')
    const [month, setMonth] = useState('')
    const [year,setYear] = useState('')
    const [error, setError] = useState({field: '', message: ''});
    const navigation = useNavigation();
    const route = useRoute();
    
    const id = route.params.id;
    const ticket = route.params.ticket;

    const goToPayment = async () => {
        navigation.navigate('Receipt', {id: event.id, ticket})
    }

    useEffect(() => {
        DataStore.query(Events, id).then(setEvent);
      }, [])

    if (!event){
        return <ActivityIndicator/>
    }

    const getTotal = () => {
        return event.price * ticket
      }


    const isValidForm = () => {
        let loginError = {field: '', message: ''}
        if((creditCardNumber === '')){
            loginError.field = 'creditCardNumber';
            loginError.message = "Credit Card Number is required"
            setError(loginError)
        } else if (creditCardNumber.length < 16){
            loginError.field = 'creditCardNumber'
            loginError.message = "Credit card must be 16 digits"
            setError(loginError)
        } else if (CVV === ''){
            loginError.field = 'CVV';
            loginError.message = "CVV is required"
            setError(loginError)
        } else if (CVV.length < 3){
            loginError.field = 'CVV';
            loginError.message = "CVV must be 3 digits"
            setError(loginError)
        } else if (month === ''){
            loginError.field = 'month'
            loginError.message = 'Month is required'
            setError(loginError)
        } else if ((month < 1) || (month > 12)){
            loginError.field = 'month'
            loginError.message = 'Invalid month'
            setError(loginError)
        } else if (year === ''){
            loginError.field = 'year'
            loginError.message = 'Year is required'
            setError(loginError)
        } else if ((year <= 2022) || (year >= 2040)){
            loginError.field = 'year'
            loginError.message = 'Invalid year'
            setError(loginError)
        }
        else{
            goToPayment()
        }
    }

    const submitPayment = () => {
       isValidForm()
    }
  return (
    <SafeAreaView style={{flex:1}}>
        <View style={{paddingLeft: 10}}>
        <Text style={styles.title}>{event.name}</Text>
        <Text style={styles.subtitle}>Tickets: {ticket}</Text>
        <Text style={[styles.subtitle, {fontFamily: 'Urbanist-SemiBold'}]}>Total: ${getTotal().toFixed(2)}</Text>
        </View>
        <View style={{height: 1, width: '100%', backgroundColor: '#800000', marginVertical: 10}}/>
        <Text style={{fontSize: 30, paddingLeft: 10, color: '#800000', fontFamily: 'Urbanist-SemiBold'}}>Payment Information</Text>

        <ScrollView contentContainerStyle={{flex:1}} keyboardShouldPersistTaps='handled'>
        <KeyboardAvoidingView style={{justifyContent: 'center', flex: 1}} behavior='height' keyboardVerticalOffset={40}>
        <Text style={[{paddingLeft: 15, marginTop: -150}, styles.creditCardInfo]}>Credit Card Number</Text>
        <TextInput style={styles.input}
            theme={{colors: {text: '#800000', primary: '#800000'}}}
            placeholder="Credit Card Number"   
            maxLength={16} 
            value={creditCardNumber}
            onChangeText={setCreditCardNumber}
            keyboardType={'numeric'}
        />
        {error.field === 'creditCardNumber' && (
            <Text style={styles.errorMessage}>{error.message}</Text>
        )}
        <Text style={[{paddingLeft: 15}, styles.creditCardInfo]}>CVV</Text>
        <TextInput style={[styles.input, {width: '30%'}]}
            theme={{colors: {text: '#800000', primary: '#800000'}}}
            placeholder="CVV"
            value={CVV}
            onChangeText={setCVV}      
            maxLength={3}
            keyboardType={"numeric"}
        />
        {error.field === 'CVV' && (
            <Text style={styles.errorMessage}>{error.message}</Text>
        )}
        <Text style={[{paddingLeft: 15, paddingVertical: 5},styles.creditCardInfo]}>Expiration Date</Text>
        <View style={{flexDirection: 'row', paddingLeft: 15,}}>
        <Text style={styles.creditCardInfo}>Month</Text>
        <Text style={[{paddingLeft: 80}, styles.creditCardInfo]}>Year</Text>
        </View>


        <View style={{flexDirection: 'row'}}>
        <TextInput style={styles.input}
            theme={{colors: {text: '#800000', primary: '#800000'}}}
            placeholder="Month" 
            value={month}
            onChangeText={setMonth}   
            maxLength={2}
            keyboardType={"numeric"}
        />
        <TextInput style={styles.input}
            theme={{colors: {text: '#800000', primary: '#800000'}}}
            placeholder="Year" 
            value={year}
            onChangeText={setYear}     
            maxLength={4}
            keyboardType={"numeric"}
        />
        </View>
        {error.field === 'month' && (
            <Text style={styles.errorMessage}>{error.message}</Text>
        )}

        {error.field === 'year' && (
            <Text style={styles.errorMessage}>{error.message}</Text>
        )}
        </KeyboardAvoidingView>
        </ScrollView>

        <View style={styles.footer}>
                      
                       <Pressable onPress={submitPayment}style={{backgroundColor:'#800000', width: '100%', alignItems: 'center', height: 60, borderRadius: 20, justifyContent: 'center'}}>
                           <Text style={styles.payButton}> PAY </Text>
                       </Pressable>
               
        </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({

    title: {
        fontSize: 35,
        color: '#800000',
        fontFamily: 'Urbanist-SemiBold'
    },

    subtitle: {
        fontSize: 25,
        fontFamily: 'Urbanist-Medium',
        color: '#800000'
    },

    input: {
        margin: 10,
        backgroundColor: 'white',
        padding:15,
        borderRadius: 15,
        borderTopEndRadius: 15,
        borderTopStartRadius: 15,
        height: 20,
        fontFamily: 'Urbanist-Regular',
        borderWidth: 2,
        borderColor: '#800000',
        overflow: 'hidden',
        borderBottomWidth: -2,
        fontSize: 20,
     },

    footer: {
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 10,
        bottom: 30,
        width: '100%',
        backgroundColor: 'white',
        height: 40,
     },

     payButton: {
        fontFamily: "Urbanist-SemiBold",
        fontSize: 20,
        color: 'white'
     },

     creditCardInfo: {
        fontSize: 18, 
        fontFamily: 'Urbanist-Regular', 
        color: '#800000'
     },

     errorMessage: {
        fontSize: 15,
        color: 'red',
        fontFamily: 'Urbanist-Medium',
        paddingLeft: 15,
        paddingBottom: 5,
     }
})

export default CreditCardScreen