import { StyleSheet, Text, View, Pressable, Image, SafeAreaView, KeyboardAvoidingView, Alert } from 'react-native'
import {Auth, DataStore} from 'aws-amplify'
import React, { useState } from 'react'
import { TextInput } from 'react-native-paper'
import {User} from '../../models'
import { useAuthContext } from '../../contexts/AuthContext'

const ProfileScreen = () => {
    const {sub, setDbUser, dbUser} = useAuthContext();

    const [name, setName] = useState(dbUser?.name || "");
    const [email, setEmail] = useState(dbUser?.email || "");
    const [phoneNumber, setPhoneNumber] = useState(dbUser?.phoneNumber || "")


    const onSave = async () => {

        if(dbUser) {
          await updateUser();
        } else {
          await  createUser();
        }
      
    };

    const updateUser = async () => {
        const user = await DataStore.save(
            User.copyOf(dbUser, (updated) => {
                updated.name = name;
                updated.email = email;
                updated.phoneNumber = phoneNumber;
            })
        );
        setDbUser(user)
    }
    const createUser = async () => {
        try{
            const user = await DataStore.save(new User({name,email, phoneNumber, sub}))
            setDbUser(user)
            } catch (e) {
                Alert.alert("Error", e.message)
            }
    }
  return (
    <KeyboardAvoidingView style={{flex:1, justifyContent: 'center'}} behavior="height" keyboardVerticalOffset={-100}>
   <View style={{flex:1}}>
   <Image source={{uri: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/College_of_Charleston_Cougars_logo.svg/880px-College_of_Charleston_Cougars_logo.svg.png'}} style={{height: 200, width: 200, alignSelf: 'center', resizeMode:'contain', flex:1}}/>
   </View>

   <View style={{flex: 1}}>
   <TextInput style={styles.input} 
   theme={{colors: {text: '#800000', primary: '#800000'}}}
   placeholder="Name"
   value={name}
   onChangeText={setName}

   />
   <TextInput style={styles.input}
   theme={{colors: {text: '#800000', primary: '#800000'}}}
   placeholder="Email"
   value={email}
   onChangeText={setEmail}
   />
   <TextInput style={styles.input} 
   theme={{colors: {text: '#800000', primary: '#800000'}}}
   placeholder="Phone Number"
   value={phoneNumber}
   onChangeText={setPhoneNumber}
   />

   <Pressable onPress={onSave} style={{backgroundColor:"#800000", width: '30%', justifyContent: 'center', alignItems: 'center', alignSelf: 'center', padding: 10, borderRadius: 20}}>
    <Text style={{fontFamily: 'Urbanist-SemiBold', color: 'white', fontSize: 18}}> Save</Text>
   </Pressable>
 </View>

   
   <View style={styles.footer}>
                       
                       <Pressable onPress={() => Auth.signOut()}style={{backgroundColor:'#800000', width: '100%', alignItems: 'center', height: 60, borderRadius: 20, justifyContent: 'center'}}>
                           <Text style={styles.payButton}> Sign Out </Text>
                       </Pressable>
               
        </View>
    </KeyboardAvoidingView>
  )
}

export default ProfileScreen

const styles = StyleSheet.create({

    profileText: {
        paddingTop: 5,
        paddingLeft: 10,
        fontSize: 20,
        fontFamily: "Urbanist-SemiBold",
    },
    infoBox: {
        height: 50,
        marginBottom: 30,
        width: '80%',
        borderWidth: 3,
        alignItems: 'flex-start',
        borderRadius: 30,
        borderColor: '#800000'
    },

    logoutButton: {
        width: '80%',
        height: 50,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderBottomWidth: 2,
        borderRadius: 50,
        backgroundColor: '#800000'
    },

    subtitle:{
        paddingLeft: 15,
        paddingTop: 5,
        fontSize: 13,
        color: 'grey',
        fontFamily: "Urbanist-SemiBold"
    },

    input: {
       margin: 10,
       backgroundColor: 'white',
       padding:15,
       borderRadius: 15,
       borderTopEndRadius: 15,
       borderTopStartRadius: 15,
       height: 20,
       fontFamily: 'Urbanist-Regular',
       borderWidth: 2,
       borderColor: '#800000',
       overflow: 'hidden',
       borderBottomWidth: -2
    },

    footer: {
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 10,
        bottom: 30,
        width: '100%',
        backgroundColor: 'white',
        height: 40,
     },

     payButton: {
        fontFamily: "Urbanist-SemiBold",
        fontSize: 20,
        color: 'white'
     }


    
})