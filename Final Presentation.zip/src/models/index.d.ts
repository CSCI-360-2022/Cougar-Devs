import { ModelInit, MutableModel } from "@aws-amplify/datastore";
// @ts-ignore
import { LazyLoading, LazyLoadingDisabled, AsyncCollection, AsyncItem } from "@aws-amplify/datastore";

type BasketMetaData = {
  readOnlyFields: 'createdAt' | 'updatedAt';
}

type BasketEventMetaData = {
  readOnlyFields: 'createdAt' | 'updatedAt';
}

type EventsMetaData = {
  readOnlyFields: 'createdAt' | 'updatedAt';
}

type OrderEventMetaData = {
  readOnlyFields: 'createdAt' | 'updatedAt';
}

type OrderMetaData = {
  readOnlyFields: 'createdAt' | 'updatedAt';
}

type UserMetaData = {
  readOnlyFields: 'createdAt' | 'updatedAt';
}

type EagerBasket = {
  readonly id: string;
  readonly BasketEvents?: (BasketEvent | null)[] | null;
  readonly userID: string;
  readonly eventsID: string;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
}

type LazyBasket = {
  readonly id: string;
  readonly BasketEvents: AsyncCollection<BasketEvent>;
  readonly userID: string;
  readonly eventsID: string;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
}

export declare type Basket = LazyLoading extends LazyLoadingDisabled ? EagerBasket : LazyBasket

export declare const Basket: (new (init: ModelInit<Basket, BasketMetaData>) => Basket) & {
  copyOf(source: Basket, mutator: (draft: MutableModel<Basket, BasketMetaData>) => MutableModel<Basket, BasketMetaData> | void): Basket;
}

type EagerBasketEvent = {
  readonly id: string;
  readonly quantity: number;
  readonly Events?: Events | null;
  readonly basketID: string;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
  readonly basketEventEventsId?: string | null;
}

type LazyBasketEvent = {
  readonly id: string;
  readonly quantity: number;
  readonly Events: AsyncItem<Events | undefined>;
  readonly basketID: string;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
  readonly basketEventEventsId?: string | null;
}

export declare type BasketEvent = LazyLoading extends LazyLoadingDisabled ? EagerBasketEvent : LazyBasketEvent

export declare const BasketEvent: (new (init: ModelInit<BasketEvent, BasketEventMetaData>) => BasketEvent) & {
  copyOf(source: BasketEvent, mutator: (draft: MutableModel<BasketEvent, BasketEventMetaData>) => MutableModel<BasketEvent, BasketEventMetaData> | void): BasketEvent;
}

type EagerEvents = {
  readonly id: string;
  readonly name: string;
  readonly price: number;
  readonly organization: string;
  readonly date: string;
  readonly description?: string | null;
  readonly image: string;
  readonly Baskets?: (Basket | null)[] | null;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
}

type LazyEvents = {
  readonly id: string;
  readonly name: string;
  readonly price: number;
  readonly organization: string;
  readonly date: string;
  readonly description?: string | null;
  readonly image: string;
  readonly Baskets: AsyncCollection<Basket>;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
}

export declare type Events = LazyLoading extends LazyLoadingDisabled ? EagerEvents : LazyEvents

export declare const Events: (new (init: ModelInit<Events, EventsMetaData>) => Events) & {
  copyOf(source: Events, mutator: (draft: MutableModel<Events, EventsMetaData>) => MutableModel<Events, EventsMetaData> | void): Events;
}

type EagerOrderEvent = {
  readonly id: string;
  readonly quantity: number;
  readonly Events?: Events | null;
  readonly orderID: string;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
  readonly orderEventEventsId?: string | null;
}

type LazyOrderEvent = {
  readonly id: string;
  readonly quantity: number;
  readonly Events: AsyncItem<Events | undefined>;
  readonly orderID: string;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
  readonly orderEventEventsId?: string | null;
}

export declare type OrderEvent = LazyLoading extends LazyLoadingDisabled ? EagerOrderEvent : LazyOrderEvent

export declare const OrderEvent: (new (init: ModelInit<OrderEvent, OrderEventMetaData>) => OrderEvent) & {
  copyOf(source: OrderEvent, mutator: (draft: MutableModel<OrderEvent, OrderEventMetaData>) => MutableModel<OrderEvent, OrderEventMetaData> | void): OrderEvent;
}

type EagerOrder = {
  readonly id: string;
  readonly userID: string;
  readonly Events?: Events | null;
  readonly total: number;
  readonly OrderEvents?: (OrderEvent | null)[] | null;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
  readonly orderEventsId?: string | null;
}

type LazyOrder = {
  readonly id: string;
  readonly userID: string;
  readonly Events: AsyncItem<Events | undefined>;
  readonly total: number;
  readonly OrderEvents: AsyncCollection<OrderEvent>;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
  readonly orderEventsId?: string | null;
}

export declare type Order = LazyLoading extends LazyLoadingDisabled ? EagerOrder : LazyOrder

export declare const Order: (new (init: ModelInit<Order, OrderMetaData>) => Order) & {
  copyOf(source: Order, mutator: (draft: MutableModel<Order, OrderMetaData>) => MutableModel<Order, OrderMetaData> | void): Order;
}

type EagerUser = {
  readonly id: string;
  readonly name?: string | null;
  readonly email?: string | null;
  readonly phoneNumber?: string | null;
  readonly Orders?: (Order | null)[] | null;
  readonly Baskets?: (Basket | null)[] | null;
  readonly sub: string;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
}

type LazyUser = {
  readonly id: string;
  readonly name?: string | null;
  readonly email?: string | null;
  readonly phoneNumber?: string | null;
  readonly Orders: AsyncCollection<Order>;
  readonly Baskets: AsyncCollection<Basket>;
  readonly sub: string;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
}

export declare type User = LazyLoading extends LazyLoadingDisabled ? EagerUser : LazyUser

export declare const User: (new (init: ModelInit<User, UserMetaData>) => User) & {
  copyOf(source: User, mutator: (draft: MutableModel<User, UserMetaData>) => MutableModel<User, UserMetaData> | void): User;
}