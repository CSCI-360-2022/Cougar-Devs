// @ts-check
import { initSchema } from '@aws-amplify/datastore';
import { schema } from './schema';



const { Basket, BasketEvent, Events, OrderEvent, Order, User } = initSchema(schema);

export {
  Basket,
  BasketEvent,
  Events,
  OrderEvent,
  Order,
  User
};