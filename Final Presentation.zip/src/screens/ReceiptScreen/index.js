import { View, Text, ActivityIndicator, SafeAreaView } from 'react-native'
import { useNavigation, useRoute } from '@react-navigation/native';
import {React, useState, useEffect} from 'react'
import { DataStore } from 'aws-amplify';
import { Events } from '../../models';
import { FontAwesome } from '@expo/vector-icons';

const ReceiptScreen = () => {

    const [event, setEvent] = useState(null);


    const navigation = useNavigation();
    const route = useRoute();
    const id = route.params?.id;
    const ticket = route.params?.ticket;

    useEffect(() => {
        DataStore.query(Events, id).then(setEvent);
      }, [])

    if (!event){
        return <ActivityIndicator/>
    }

    const getTotal = () => {
        return event.price * ticket
    }
  return (
    <SafeAreaView style={{flex: 1, justifyContent: 'center'}}>
    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
      <Text style={{fontSize: 40, fontFamily: 'Urbanist-SemiBold', color: '#800000'}}>Receipt</Text>
    </View> 
    <View style={{borderWidth: 1, borderColor: '#800000', width: '80%', alignSelf: 'center'}}/>
    <View style={{paddingHorizontal: 15, flex: 9, justifyContent: 'center'}}>
      <View style={{flexDirection: 'row', justifyContent: 'space-between', paddingBottom: 15}}>
        <Text style={{fontSize: 20, fontFamily: 'Urbanist-SemiBold', color: "#800000"}}>Event: </Text>
        <Text style={{fontSize: 20, fontFamily: 'Urbanist-SemiBold', color: "#800000"}}>{event.name}</Text>
      </View>

      <View style={{flexDirection: 'row', justifyContent: 'space-between', paddingBottom: 15}}>
        <Text style={{fontSize: 20, fontFamily: 'Urbanist-SemiBold', color: "#800000"}}>Number of Tickets: </Text>
        <Text style={{fontSize: 20, fontFamily: 'Urbanist-SemiBold', color: "#800000"}}>{ticket}</Text>
      </View>

      <View style={{flexDirection: 'row', justifyContent: 'space-between', paddingBottom: 15}}>
        <Text style={{fontSize: 20, fontFamily: 'Urbanist-SemiBold', color: "#800000"}}>Date: </Text>
        <Text style={{fontSize: 20, fontFamily: 'Urbanist-SemiBold', color: "#800000"}}>{event.date}</Text>
      </View>

      <View style={{flexDirection: 'row', justifyContent: 'space-between', paddingBottom: 15}}>
        <Text style={{fontSize: 20, fontFamily: 'Urbanist-SemiBold', color: "#800000"}}>Organization: </Text>
        <Text style={{fontSize: 20, fontFamily: 'Urbanist-SemiBold', color: "#800000"}}>{event.organization}</Text>
      </View>


      <View style={{flexDirection: 'row', justifyContent: 'space-between', paddingBottom: 15}}>
        <Text style={{fontSize: 20, fontFamily: 'Urbanist-SemiBold', color: "#800000"}}>Total:  </Text>
        <Text style={{fontSize: 20, fontFamily: 'Urbanist-SemiBold', color: "#800000"}}>${getTotal().toFixed(2)}</Text>
      </View>
      </View>

      <View style={{flex:2, justifyContent: 'center', alignItems: 'center'}}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
        <Text style={{fontSize: 40, fontFamily: 'Urbanist-SemiBold', color: '#800000'}}>Thank you</Text>
        <FontAwesome name="smile-o" size={35} color="#800000" style={{paddingLeft: 20}}/>
        </View>
      </View>
    </SafeAreaView>
  )
}

export default ReceiptScreen