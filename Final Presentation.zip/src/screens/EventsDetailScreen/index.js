import { View, Text, Image, FlatList, StyleSheet, Button, TouchableOpacity, ScrollView, Pressable, ActivityIndicator } from "react-native"
import { Ionicons, EvilIcons } from '@expo/vector-icons';
import { useState, useEffect } from "react";
import { useRoute, useNavigation } from "@react-navigation/native";
import { DataStore } from "aws-amplify";
import { Events } from "../../models";




const EventsDetailScreen = () => {
    const [event, setEvent] = useState(null);
    const [maxTicket, setMaxTicket] = useState(5);

    const route = useRoute();
    const navigation = useNavigation();
    
    const id = route.params?.id;

    

    const fetchEvents = async () => {
        const results = await DataStore.query(Events, id);
        setEvent(results)
      }
    
      useEffect(() => {
        fetchEvents();
      }, [])
    
    if(!event) {
        return <ActivityIndicator style={{flex:1}}/>
    }



    const onPress = () => {
      navigation.navigate("Cart", {id: event.id, maxTicket})
      console.log(maxTicket)
    };

    return (
        <View style={styles.pageContainer}>
            <Image source={{uri: event.image}} style={styles.image}/>

            
            <Ionicons onPress={() => navigation.goBack()}name="arrow-back-circle" size={45} color="white" style={styles.iconContainer}/>
            
                    <ScrollView style={[styles.container, {paddingBottom: 400}]} showsVerticalScrollIndicator={false}>
                    <Text style={styles.title}>{event.name}</Text>
                    <View style={styles.line}/>
                    {/* DESCRIPTION */}
                
                    <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
                    <Text style={styles.subtitle}>{event.organization}</Text>
                    <Text style={styles.subtitle}>{event.date}</Text>
                    </View>
                    <Text style={styles.price}>${event.price.toFixed(2)}</Text>
            
                    <Text style={styles.description}>{event.description}</Text>
                    
                    </ScrollView>

                <View style={styles.footer}>
                       
                        <Pressable onPress={onPress} style={{backgroundColor:'#800000', width: '100%', alignItems: 'center', height: 60, borderRadius: 20, justifyContent: 'center'}}>
                            <Text style={styles.payButton}> Add to basket </Text>
                        </Pressable>
                
                </View>
                
        </View>
    )

}

const styles = StyleSheet.create({
    pageContainer:{
        flex:1
    },
    image: {
        width: '100%',
        aspectRatio: 4/3,
    },

    iconContainer:{
        position: 'absolute',
        top: 50,
        left: 10,
    },
    title: {
        color: "#800000",
        fontSize: 35,
        fontWeight: "600",
        fontFamily: 'Urbanist-SemiBold'
    },

    price: {
        paddingTop: 10,
        color: '#800000',
        fontSize: 25,
        fontFamily: 'Urbanist-Medium',
    },

    line:{
        width: '100%',
        paddingBottom: 10,
        borderBottomColor: 'black',
        borderBottomWidth: StyleSheet.hairlineWidth,
    },

    description: {
        paddingVertical: 10,
        fontFamily: 'Urbanist-Regular',
        fontSize: 18,
        paddingBottom: 30,
    },

    container: {
        margin: 10,
    },

    tickets: {
        flexDirection: 'row',
        margin: 10,
        alignItems: 'center'
    },
    
    ticketText: {
        fontFamily: 'Urbanist-Regular',
        fontSize: 18,
    },

    subtitle: {
        fontFamily: 'Urbanist-Regular',
        fontSize: 20,
        paddingVertical: 3,
        paddingTop: 10,
    },

    footer: {
       alignItems: 'center',
       justifyContent: 'space-between',
       paddingHorizontal: 10,
       bottom: 30,
       width: '100%',
       backgroundColor: 'white',
       height: 40,
    },

    payButton: {
        fontFamily: 'Urbanist-SemiBold',
        fontSize: 15,
        color: 'white',
        borderRadius: 10,
        paddingVertical: 15,
        paddingHorizontal: 10,
    }
})

export default EventsDetailScreen;