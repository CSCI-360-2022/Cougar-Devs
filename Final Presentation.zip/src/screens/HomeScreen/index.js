import { StyleSheet, Image, FlatList,View, Text, SafeAreaView, TouchableOpacity, TextInput } from 'react-native';
import EventItem from '../../components/EventItem';
import SearchBar from '../../components/searchBar';
import { useState, useEffect } from 'react';
import { DataStore } from 'aws-amplify';
import { Events } from '../../models';

export default function HomeScreen() {

  const [events, setEvents] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [search, setSearch] = useState('');

  const fetchEvents = async () => {
    const results = await DataStore.query(Events);
    setEvents(results)
    setFilteredData(results)
  }

  useEffect(() => {
    fetchEvents();
  }, []) //executed only the first time the component mount

  const searchFilter = (text) => {
    if (text) {
      const newData = events.filter((item) => {
        const itemData = item.name ? 
                            item.name.toUpperCase() 
                            : ''.toUpperCase()
        const textData = text.toUpperCase();
        return itemData.indexOf(textData) > -1;
      });
      setFilteredData(newData);
      setSearch(text);
    } else {
      setFilteredData(events);
      setSearch(text);
    }
  }

  return (
    <SafeAreaView>
   <SearchBar value={search} onChangeText={(text) => searchFilter(text)}/>
    <FlatList data={filteredData}
    showsVerticalScrollIndicator={false}
    contentContainerStyle={{flexGrow: 1,justifyContent: 'center',alignItems: 'center', paddingBottom: 50}}
    renderItem={({item}) => <EventItem event={item}/>}/>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
 
  searchBar:{
    height: 50,
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.2)',
    marginHorizontal: 10,
    marginVertical: 10,
    borderRadius: 25,
    paddingLeft: 15,
    fontSize: 17,
    fontFamily: "Urbanist-Medium"
  }

});
