import { createContext, useState, useEffect, useContext } from "react";
import { DataStore } from "aws-amplify";
import { Basket, BasketEvent } from "../models";
import { useAuthContext } from "./AuthContext";


const BasketContext = createContext({})

const BasketContextProvider = ({children}) => {
    const {sub} = useAuthContext();
    const {event, setEvents} = useState(null);
    const [basket, setBasket] = useState(null);

    const addEventToBasket = (event, quantity) => {
        console.log(event, quantity)
        
        //get the existing basket, or create a new one


        // create an BasketEvent item and save on database

    }



    return(
        <BasketContext.Provider value={{addEventToBasket}}>
            {children}
        </BasketContext.Provider>
    )
}

export default BasketContextProvider;

export const useBasketContext = () => useContext(BasketContext);